package com.example.latihanpertemuan7.DB

data class DataModelUser (
    var email   : String ="",
    var pass    : String ="",
    var fullname: String =""
)
